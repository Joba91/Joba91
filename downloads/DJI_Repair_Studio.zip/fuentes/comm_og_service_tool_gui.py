#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""GUI wrapper for comm_og_service_tool.py."""

import os
import sys
import tkinter as tk
from ctypes import sizeof
from contextlib import redirect_stderr, redirect_stdout
import io
from tkinter import messagebox, ttk
from types import SimpleNamespace

from comm_mkdupc import ACK_TYPE, CMD_SET_TYPE, COMM_DEV_TYPE, DJICmdV1Header, get_known_payload
from comm_og_service_tool import (
    CAMERA_CALIB_CMD,
    FLYC_PARAM_CMD,
    GIMBAL_CALIB_CMD,
    PRODUCT_CODE,
    SERVICE_CMD,
    do_camera_calib_request,
    do_flyc_param_request,
    do_gimbal_calib_request,
    do_module_info_request,
    do_repair_assist_request,
    parse_version_inquiry_payload,
    open_serial_port,
    send_request_and_receive_reply,
)

try:
    import serial.tools.list_ports
except Exception:
    serial = None
else:
    serial = serial


ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
TOOL_PATH = os.path.join(ROOT_DIR, "comm_og_service_tool.py")
PRODUCT_DISPLAY_TO_CODE = {
    "DJI Mavic 4 Pro (experimental)": "MAVIC4PRO",
    "Mavic 3 (WM260)": "WM260",
    "DJI Mini 5 Pro (MT5MFND)": "MT5MFND",
}
MODERN_ALT_PRODUCT_CODES = {"WM260", "MT5MFND"}
PRODUCTS = [
    "DJI Mavic 4 Pro (experimental)",
    "Mavic 3 (WM260)",
    "DJI Mini 5 Pro (MT5MFND)",
    "A2", "P330", "P330V", "P330Z", "P330VP", "WM610", "P3X", "P3S", "MAT100",
    "P3C", "MG1", "WM325", "WM330", "MAT600", "WM220", "WM620", "WM331", "MAT200",
    "MG1S", "WM332", "WM100", "WM230", "WM335", "WM240", "WM245", "WM246", "WM160",
    "WM231", "WM232", "WM260", "WM247", "WM161", "MT5MFND",
]
FMTS = ["simple", "1line", "2line", "tab", "csv"]


class OGServiceToolGui(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("DJI REPAIR Studio")
        self.geometry("1080x760")
        self.minsize(960, 700)

        self.connection_mode = tk.StringVar(value="bulk")
        self.port_var = tk.StringVar()
        self.product_var = tk.StringVar(value="Mavic 3 (WM260)")
        self.baudrate_var = tk.StringVar(value="9600")
        self.timeout_var = tk.StringVar(value="500")
        self.verbose_var = tk.StringVar(value="1")
        self.dry_test_var = tk.BooleanVar(value=False)

        self.flyc_action_var = tk.StringVar(value="list")
        self.flyc_start_var = tk.StringVar(value="0")
        self.flyc_count_var = tk.StringVar(value="100")
        self.flyc_param_var = tk.StringVar()
        self.flyc_value_var = tk.StringVar()
        self.flyc_alt_var = tk.BooleanVar(value=False)
        self.wm260_write_unlock_var = tk.BooleanVar(value=False)
        self.flyc_fmt_var = tk.StringVar(value="simple")

        self.gimbal_action_var = tk.StringVar(value="JointCoarse")

        self.camera_action_var = tk.StringVar(value="EncryptCheck")
        self.pairkey_var = tk.StringVar()
        self.camera_force_var = tk.BooleanVar(value=False)
        self.module_info_target_var = tk.StringVar(value="all")
        self.module_info_retry_var = tk.StringVar(value="3")
        self.repair_error_code_var = tk.StringVar(value="all")
        self.repair_retry_var = tk.StringVar(value="3")

        self.command_preview_var = tk.StringVar(value="Aquí verás el comando generado.")
        self.status_var = tk.StringVar(value="Configura la conexión y ejecuta una acción.")
        self.device_status_var = tk.StringVar(value="Estado equipo: sin sondeo")
        self.device_name_var = tk.StringVar(value="Nombre: -")
        self.device_hw_var = tk.StringVar(value="HW: -")
        self.device_loader_var = tk.StringVar(value="Loader: -")
        self.device_app_var = tk.StringVar(value="App/FW: -")
        self.device_link_var = tk.StringVar(value="Conexion: -")
        self.port_details = {}

        self._build_ui()
        self.refresh_ports()
        self._update_flyc_form()
        self._update_camera_form()
        self.update_command_preview()

    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        top = ttk.Frame(self, padding=12)
        top.grid(row=0, column=0, sticky="ew")
        top.columnconfigure(1, weight=1)
        top.columnconfigure(3, weight=1)

        ttk.Label(top, text="Conexion").grid(row=0, column=0, sticky="w")
        conn_frame = ttk.Frame(top)
        conn_frame.grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(conn_frame, text="Puerto serie", variable=self.connection_mode, value="port", command=self.update_command_preview).grid(row=0, column=0, padx=(0, 8))
        ttk.Radiobutton(conn_frame, text="USB bulk", variable=self.connection_mode, value="bulk", command=self.update_command_preview).grid(row=0, column=1)

        ttk.Label(top, text="Puerto").grid(row=0, column=2, sticky="w", padx=(16, 6))
        port_frame = ttk.Frame(top)
        port_frame.grid(row=0, column=3, sticky="ew")
        port_frame.columnconfigure(0, weight=1)
        self.port_combo = ttk.Combobox(port_frame, textvariable=self.port_var, state="normal")
        self.port_combo.grid(row=0, column=0, sticky="ew")
        ttk.Button(port_frame, text="Actualizar", command=self.refresh_ports).grid(row=0, column=1, padx=(6, 0))

        ttk.Label(top, text="Producto").grid(row=1, column=0, sticky="w", pady=(10, 0))
        product_combo = ttk.Combobox(top, textvariable=self.product_var, values=PRODUCTS, state="readonly")
        product_combo.grid(row=1, column=1, sticky="ew", pady=(10, 0))
        product_combo.bind("<<ComboboxSelected>>", lambda _e: self._update_flyc_form())

        ttk.Label(top, text="Baudrate").grid(row=1, column=2, sticky="w", padx=(16, 6), pady=(10, 0))
        ttk.Entry(top, textvariable=self.baudrate_var).grid(row=1, column=3, sticky="ew", pady=(10, 0))

        ttk.Label(top, text="Timeout ms").grid(row=2, column=0, sticky="w", pady=(10, 0))
        ttk.Entry(top, textvariable=self.timeout_var).grid(row=2, column=1, sticky="ew", pady=(10, 0))

        ttk.Label(top, text="Verbose").grid(row=2, column=2, sticky="w", padx=(16, 6), pady=(10, 0))
        verbose_combo = ttk.Combobox(top, textvariable=self.verbose_var, values=["0", "1", "2", "3"], state="readonly")
        verbose_combo.grid(row=2, column=3, sticky="ew", pady=(10, 0))
        verbose_combo.bind("<<ComboboxSelected>>", lambda _e: self.update_command_preview())

        flags = ttk.Frame(top)
        flags.grid(row=3, column=0, columnspan=4, sticky="w", pady=(10, 0))
        ttk.Checkbutton(flags, text="Dry test", variable=self.dry_test_var, command=self.update_command_preview).grid(row=0, column=0)

        status_box = ttk.LabelFrame(self, text="Estado del equipo", padding=12)
        status_box.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 8))
        status_box.columnconfigure(0, weight=1)
        status_box.columnconfigure(1, weight=1)
        ttk.Label(status_box, textvariable=self.device_status_var).grid(row=0, column=0, sticky="w")
        ttk.Button(status_box, text="Sondear equipo", command=self.probe_device).grid(row=0, column=1, sticky="e")
        ttk.Label(status_box, textvariable=self.device_name_var).grid(row=1, column=0, sticky="w", pady=(8, 0))
        ttk.Label(status_box, textvariable=self.device_link_var).grid(row=1, column=1, sticky="w", pady=(8, 0))
        ttk.Label(status_box, textvariable=self.device_hw_var).grid(row=2, column=0, sticky="w", pady=(6, 0))
        ttk.Label(status_box, textvariable=self.device_loader_var).grid(row=2, column=1, sticky="w", pady=(6, 0))
        ttk.Label(status_box, textvariable=self.device_app_var).grid(row=3, column=0, sticky="w", pady=(6, 0))

        notebook = ttk.Notebook(self)
        notebook.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 8))
        notebook.bind("<<NotebookTabChanged>>", lambda _e: self.update_command_preview())
        self.notebook = notebook

        self.flyc_tab = ttk.Frame(notebook, padding=12)
        self.gimbal_tab = ttk.Frame(notebook, padding=12)
        self.camera_tab = ttk.Frame(notebook, padding=12)
        self.module_info_tab = ttk.Frame(notebook, padding=12)
        self.repair_assist_tab = ttk.Frame(notebook, padding=12)
        self.yandron_tab = ttk.Frame(notebook, padding=12)
        notebook.add(self.flyc_tab, text="FlycParam")
        notebook.add(self.gimbal_tab, text="GimbalCalib")
        notebook.add(self.camera_tab, text="CameraCalib")
        notebook.add(self.module_info_tab, text="ModuleInfo")
        notebook.add(self.repair_assist_tab, text="RepairAssist")
        notebook.add(self.yandron_tab, text="YanDron")

        self._build_flyc_tab()
        self._build_gimbal_tab()
        self._build_camera_tab()
        self._build_module_info_tab()
        self._build_repair_assist_tab()
        ttk.Label(self.yandron_tab, text="YanDron: analizador HEX, progreso y calibraciones experimentales para modelos declarados.\nNo incluye movimiento independiente de ejes ni escritura de datos IMU fijos.", wraplength=850).pack(anchor="w")
        ttk.Button(self.yandron_tab, text="Abrir panel YanDron", command=self.open_yandron_panel).pack(anchor="w", pady=10)

        middle = ttk.Frame(self, padding=(12, 0, 12, 8))
        middle.grid(row=3, column=0, sticky="nsew")
        middle.columnconfigure(0, weight=1)
        middle.rowconfigure(2, weight=1)

        ttk.Label(middle, text="Comando").grid(row=0, column=0, sticky="w")
        preview = ttk.Entry(middle, textvariable=self.command_preview_var, state="readonly")
        preview.grid(row=1, column=0, sticky="ew", pady=(4, 10))

        log_frame = ttk.Frame(middle)
        log_frame.grid(row=2, column=0, sticky="nsew")
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)

        self.log = tk.Text(log_frame, wrap="word")
        self.log.grid(row=0, column=0, sticky="nsew")
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.log.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.log.configure(yscrollcommand=scroll.set)

        bottom = ttk.Frame(self, padding=12)
        bottom.grid(row=4, column=0, sticky="ew")
        bottom.columnconfigure(0, weight=1)
        ttk.Label(bottom, textvariable=self.status_var, anchor="w").grid(row=0, column=0, sticky="ew")
        ttk.Button(bottom, text="Ejecutar", command=self.run_current_command).grid(row=0, column=1, padx=(12, 6))
        ttk.Button(bottom, text="Limpiar log", command=self.clear_log).grid(row=0, column=2)

        for variable in (
            self.port_var, self.product_var, self.baudrate_var, self.timeout_var,
            self.flyc_action_var, self.flyc_start_var, self.flyc_count_var,
            self.flyc_param_var, self.flyc_value_var, self.flyc_fmt_var,
            self.gimbal_action_var, self.camera_action_var, self.pairkey_var,
            self.module_info_target_var, self.module_info_retry_var,
            self.repair_error_code_var, self.repair_retry_var,
        ):
            variable.trace_add("write", lambda *_args: self.update_command_preview())

    def _build_flyc_tab(self):
        tab = self.flyc_tab
        for idx in range(2):
            tab.columnconfigure(idx, weight=1 if idx == 1 else 0)

        ttk.Label(tab, text="Accion").grid(row=0, column=0, sticky="w")
        action = ttk.Combobox(tab, textvariable=self.flyc_action_var, values=["list", "get", "set"], state="readonly")
        action.grid(row=0, column=1, sticky="ew")
        action.bind("<<ComboboxSelected>>", lambda _e: self._update_flyc_form())

        ttk.Label(tab, text="Start").grid(row=1, column=0, sticky="w", pady=(10, 0))
        self.flyc_start_entry = ttk.Entry(tab, textvariable=self.flyc_start_var)
        self.flyc_start_entry.grid(row=1, column=1, sticky="ew", pady=(10, 0))

        ttk.Label(tab, text="Count").grid(row=2, column=0, sticky="w", pady=(10, 0))
        self.flyc_count_entry = ttk.Entry(tab, textvariable=self.flyc_count_var)
        self.flyc_count_entry.grid(row=2, column=1, sticky="ew", pady=(10, 0))

        ttk.Label(tab, text="Parametro").grid(row=3, column=0, sticky="w", pady=(10, 0))
        self.flyc_param_entry = ttk.Entry(tab, textvariable=self.flyc_param_var)
        self.flyc_param_entry.grid(row=3, column=1, sticky="ew", pady=(10, 0))

        ttk.Label(tab, text="Valor").grid(row=4, column=0, sticky="w", pady=(10, 0))
        self.flyc_value_entry = ttk.Entry(tab, textvariable=self.flyc_value_var)
        self.flyc_value_entry.grid(row=4, column=1, sticky="ew", pady=(10, 0))

        ttk.Label(tab, text="Formato").grid(row=5, column=0, sticky="w", pady=(10, 0))
        fmt = ttk.Combobox(tab, textvariable=self.flyc_fmt_var, values=FMTS, state="readonly")
        fmt.grid(row=5, column=1, sticky="ew", pady=(10, 0))
        fmt.bind("<<ComboboxSelected>>", lambda _e: self.update_command_preview())

        self.flyc_alt_check = ttk.Checkbutton(tab, text="Usar metodo alternativo", variable=self.flyc_alt_var, command=self.update_command_preview)
        self.flyc_alt_check.grid(row=6, column=0, columnspan=2, sticky="w", pady=(10, 0))
        self.wm260_write_unlock_check = ttk.Checkbutton(tab, text="Habilitar escritura moderna", variable=self.wm260_write_unlock_var, command=self.update_command_preview)
        self.wm260_write_unlock_check.grid(row=7, column=0, columnspan=2, sticky="w", pady=(10, 0))

    def _build_gimbal_tab(self):
        tab = self.gimbal_tab
        tab.columnconfigure(1, weight=1)
        ttk.Label(tab, text="Accion").grid(row=0, column=0, sticky="w")
        action = ttk.Combobox(tab, textvariable=self.gimbal_action_var, values=["JointCoarse", "LinearHall"], state="readonly")
        action.grid(row=0, column=1, sticky="ew")
        action.bind("<<ComboboxSelected>>", lambda _e: self.update_command_preview())
        ttk.Label(tab, text="Estas opciones ejecutan calibraciones del gimbal sobre el equipo conectado.", wraplength=500).grid(row=1, column=0, columnspan=2, sticky="w", pady=(12, 0))

    def _build_camera_tab(self):
        tab = self.camera_tab
        tab.columnconfigure(1, weight=1)
        ttk.Label(tab, text="Accion").grid(row=0, column=0, sticky="w")
        action = ttk.Combobox(tab, textvariable=self.camera_action_var, values=["EncryptCheck", "EncryptPair"], state="readonly")
        action.grid(row=0, column=1, sticky="ew")
        action.bind("<<ComboboxSelected>>", lambda _e: self._update_camera_form())

        ttk.Label(tab, text="Pair key hex").grid(row=1, column=0, sticky="w", pady=(10, 0))
        self.pairkey_entry = ttk.Entry(tab, textvariable=self.pairkey_var)
        self.pairkey_entry.grid(row=1, column=1, sticky="ew", pady=(10, 0))

        self.force_check = ttk.Checkbutton(tab, text="Forzar escritura", variable=self.camera_force_var, command=self.update_command_preview)
        self.force_check.grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 0))

    def _build_module_info_tab(self):
        tab = self.module_info_tab
        tab.columnconfigure(1, weight=1)

        ttk.Label(tab, text="Modulo").grid(row=0, column=0, sticky="w")
        target = ttk.Combobox(
            tab,
            textvariable=self.module_info_target_var,
            values=["all", "flycontroller", "gimbal", "camera", "battery"],
            state="readonly",
        )
        target.grid(row=0, column=1, sticky="ew")
        target.bind("<<ComboboxSelected>>", lambda _e: self.update_command_preview())

        ttk.Label(tab, text="Reintentos").grid(row=1, column=0, sticky="w", pady=(10, 0))
        ttk.Entry(tab, textvariable=self.module_info_retry_var).grid(row=1, column=1, sticky="ew", pady=(10, 0))

    def _build_repair_assist_tab(self):
        tab = self.repair_assist_tab
        tab.columnconfigure(1, weight=1)

        ttk.Label(tab, text="Codigo").grid(row=0, column=0, sticky="w")
        code = ttk.Combobox(
            tab,
            textvariable=self.repair_error_code_var,
            values=["all", "40021", "1D020001"],
            state="readonly",
        )
        code.grid(row=0, column=1, sticky="ew")
        code.bind("<<ComboboxSelected>>", lambda _e: self.update_command_preview())

        ttk.Label(tab, text="Reintentos").grid(row=1, column=0, sticky="w", pady=(10, 0))
        ttk.Entry(tab, textvariable=self.repair_retry_var).grid(row=1, column=1, sticky="ew", pady=(10, 0))

    def refresh_ports(self):
        ports = []
        self.port_details = {}
        if serial is not None:
            try:
                for port in serial.tools.list_ports.comports():
                    ports.append(port.device)
                    description = getattr(port, "description", "") or ""
                    hwid = getattr(port, "hwid", "") or ""
                    vid = getattr(port, "vid", None)
                    pid = getattr(port, "pid", None)
                    self.port_details[port.device] = {
                        "description": description,
                        "hwid": hwid,
                        "vid": vid,
                        "pid": pid,
                        "is_dji": (vid == 0x2CA3) or ("2CA3" in hwid.upper()) or ("DJI" in description.upper()),
                    }
            except Exception:
                ports = []
        self.port_combo["values"] = ports
        preferred_port = None
        for port in ports:
            if self.port_details.get(port, {}).get("is_dji"):
                preferred_port = port
                break
        if preferred_port:
            self.port_var.set(preferred_port)
            details = self.port_details.get(preferred_port, {})
            self.device_link_var.set("Conexion: puerto DJI detectado en {} ({})".format(preferred_port, details.get("description", "-")))
            self.status_var.set("Puerto DJI detectado automáticamente.")
        elif ports and (not self.port_var.get() or self.port_var.get() not in ports):
            self.port_var.set(ports[0])
            self.device_link_var.set("Conexion: puerto disponible {}".format(ports[0]))
        elif not ports:
            self.device_link_var.set("Conexion: no se detectan puertos serie DJI")
        self.update_command_preview()

    def _update_flyc_form(self):
        action = self.flyc_action_var.get()
        list_mode = action == "list"
        get_mode = action == "get"
        set_mode = action == "set"
        if self.selected_product_code() in MODERN_ALT_PRODUCT_CODES and not list_mode:
            self.flyc_alt_var.set(True)
        if self.selected_product_code() not in MODERN_ALT_PRODUCT_CODES or not set_mode:
            self.wm260_write_unlock_var.set(False)

        self.flyc_start_entry.configure(state="normal" if list_mode else "disabled")
        self.flyc_count_entry.configure(state="normal" if list_mode else "disabled")
        self.flyc_param_entry.configure(state="normal" if (get_mode or set_mode) else "disabled")
        self.flyc_value_entry.configure(state="normal" if set_mode else "disabled")
        self.flyc_alt_check.configure(state="normal" if (get_mode or set_mode) else "disabled")
        self.wm260_write_unlock_check.configure(state="normal" if (self.selected_product_code() in MODERN_ALT_PRODUCT_CODES and set_mode) else "disabled")
        self.update_command_preview()

    def _update_camera_form(self):
        pair_mode = self.camera_action_var.get() == "EncryptPair"
        self.pairkey_entry.configure(state="normal" if pair_mode else "disabled")
        self.force_check.configure(state="normal" if pair_mode else "disabled")
        self.update_command_preview()

    def current_service_name(self):
        tab_index = self.notebook.index(self.notebook.select())
        if tab_index == 0:
            return "FlycParam"
        if tab_index == 1:
            return "GimbalCalib"
        if tab_index == 2:
            return "CameraCalib"
        if tab_index == 3:
            return "ModuleInfo"
        if tab_index == 4:
            return "RepairAssist"
        return "YanDron"

    def selected_product_code(self):
        product = self.product_var.get().strip()
        return PRODUCT_DISPLAY_TO_CODE.get(product, product)

    def build_command(self):
        if self.current_service_name() == "YanDron":
            return ["YanDron: abrir panel dedicado; acciones con conexion actual y analisis HEX sin conexion"]
        if self.selected_product_code() == "MAVIC4PRO" and self.current_service_name() not in ("ModuleInfo", "RepairAssist"):
            raise ValueError("Mavic 4 Pro: use ModuleInfo o RepairAssist (consulta de versiones). Calibracion y parametros pendientes de validar.")
        cmd = [sys.executable, TOOL_PATH]

        if self.connection_mode.get() == "bulk":
            cmd.append("--bulk")
        else:
            port = self.port_var.get().strip()
            if not port:
                raise ValueError("Selecciona un puerto serie o usa USB bulk.")
            cmd.extend(["--port", port])

        baudrate = self.baudrate_var.get().strip()
        timeout = self.timeout_var.get().strip()
        product = self.selected_product_code()
        verbose = int(self.verbose_var.get().strip() or "0")

        if not product:
            raise ValueError("Selecciona un producto.")
        if not baudrate.isdigit():
            raise ValueError("El baudrate debe ser numerico.")
        if not timeout.isdigit():
            raise ValueError("El timeout debe ser numerico.")

        cmd.extend(["-b", baudrate, "-w", timeout])
        if self.dry_test_var.get():
            cmd.append("--dry-test")
        if product in MODERN_ALT_PRODUCT_CODES and self.wm260_write_unlock_var.get():
            cmd.append("--allow-modern-set")
        if verbose > 0:
            cmd.append("-" + ("v" * verbose))

        cmd.append(product)

        service = self.current_service_name()
        cmd.append(service)

        if service == "FlycParam":
            action = self.flyc_action_var.get()
            fmt = self.flyc_fmt_var.get().strip() or "simple"
            cmd.append(action)
            if action == "list":
                cmd.extend(["-s", self.flyc_start_var.get().strip() or "0"])
                cmd.extend(["-c", self.flyc_count_var.get().strip() or "100"])
                cmd.extend(["-f", fmt])
            elif action == "get":
                param_name = self.flyc_param_var.get().strip()
                if not param_name:
                    raise ValueError("Escribe el nombre del parametro.")
                cmd.append(param_name)
                if self.flyc_alt_var.get():
                    cmd.append("--alt")
                cmd.extend(["-f", fmt])
            elif action == "set":
                param_name = self.flyc_param_var.get().strip()
                param_value = self.flyc_value_var.get().strip()
                if not param_name:
                    raise ValueError("Escribe el nombre del parametro.")
                if not param_value:
                    raise ValueError("Escribe el valor del parametro.")
                cmd.extend([param_name, param_value])
                if self.flyc_alt_var.get():
                    cmd.append("--alt")
                cmd.extend(["-f", fmt])
        elif service == "GimbalCalib":
            cmd.append(self.gimbal_action_var.get())
        elif service == "CameraCalib":
            action = self.camera_action_var.get()
            cmd.append(action)
            if action == "EncryptPair":
                pairkey = self.pairkey_var.get().strip()
                if pairkey:
                    cmd.extend(["-k", pairkey])
                if self.camera_force_var.get():
                    cmd.append("--force")
        elif service == "ModuleInfo":
            retry = self.module_info_retry_var.get().strip() or "3"
            if not retry.isdigit():
                raise ValueError("Los reintentos deben ser numericos.")
            cmd.append(self.module_info_target_var.get().strip() or "all")
            cmd.extend(["--retry", retry])
        else:
            retry = self.repair_retry_var.get().strip() or "3"
            if not retry.isdigit():
                raise ValueError("Los reintentos deben ser numericos.")
            cmd.append(self.repair_error_code_var.get().strip() or "all")
            cmd.extend(["--retry", retry])

        return cmd

    @staticmethod
    def _format_fw_version(value):
        return "{:02d}.{:02d}.{:04d}".format((value >> 24) & 0xFF, (value >> 16) & 0xFF, value & 0xFFFF)

    def _build_runtime_options(self):
        product = self.selected_product_code()
        baudrate = self.baudrate_var.get().strip()
        timeout = self.timeout_var.get().strip()
        if not product:
            raise ValueError("Selecciona un producto.")
        if not baudrate.isdigit():
            raise ValueError("El baudrate debe ser numerico.")
        if not timeout.isdigit():
            raise ValueError("El timeout debe ser numerico.")

        port = self.port_var.get().strip()
        if self.connection_mode.get() != "bulk" and not port:
            raise ValueError("Selecciona un puerto serie o usa USB bulk.")

        return SimpleNamespace(
            bulk=(self.connection_mode.get() == "bulk"),
            port=port,
            baudrate=int(baudrate),
            timeout=int(timeout),
            dry_test=self.dry_test_var.get(),
            allow_wm260_set=self.wm260_write_unlock_var.get(),
            allow_modern_set=self.wm260_write_unlock_var.get(),
            verbose=int(self.verbose_var.get().strip() or "0"),
        )

    def _build_backend_options(self):
        self.build_command()  # Enforce the same profile restrictions for direct dispatch.
        po = self._build_runtime_options()
        po.product = PRODUCT_CODE.from_name(self.selected_product_code())
        service = self.current_service_name()
        po.svcmd = SERVICE_CMD.from_name(service)

        if service == "FlycParam":
            action = self.flyc_action_var.get()
            po.subcmd = FLYC_PARAM_CMD.from_name(action.upper())
            po.fmt = self.flyc_fmt_var.get().strip() or "simple"
            po.start = int(self.flyc_start_var.get().strip() or "0")
            po.count = int(self.flyc_count_var.get().strip() or "100")
            po.param_name = self.flyc_param_var.get().strip()
            po.param_value = self.flyc_value_var.get().strip()
            po.alt = self.flyc_alt_var.get()
            if po.subcmd != FLYC_PARAM_CMD.LIST and not po.param_name:
                raise ValueError("Escribe el nombre del parametro.")
            if po.subcmd == FLYC_PARAM_CMD.SET and not po.param_value:
                raise ValueError("Escribe el valor del parametro.")
        elif service == "GimbalCalib":
            po.subcmd = GIMBAL_CALIB_CMD.from_name(self.gimbal_action_var.get().upper())
        elif service == "CameraCalib":
            po.subcmd = CAMERA_CALIB_CMD.from_name(self.camera_action_var.get().upper())
            po.force = self.camera_force_var.get()
            pairkey = self.pairkey_var.get().strip()
            po.pairkey = bytes.fromhex(pairkey) if pairkey else None
        elif service == "ModuleInfo":
            retry = self.module_info_retry_var.get().strip() or "3"
            if not retry.isdigit():
                raise ValueError("Los reintentos deben ser numericos.")
            po.module = self.module_info_target_var.get().strip() or "all"
            po.retry = int(retry)
        else:
            retry = self.repair_retry_var.get().strip() or "3"
            if not retry.isdigit():
                raise ValueError("Los reintentos deben ser numericos.")
            po.error_code = self.repair_error_code_var.get().strip() or "all"
            po.retry = int(retry)

        return po

    def _reset_probe_labels(self):
        self.device_name_var.set("Nombre: -")
        self.device_hw_var.set("HW: -")
        self.device_loader_var.set("Loader: -")
        self.device_app_var.set("App/FW: -")
        if self.connection_mode.get() == "bulk":
            self.device_link_var.set("Conexion: USB bulk")
        else:
            port = self.port_var.get().strip()
            if port:
                self.device_link_var.set("Conexion: Puerto {}".format(port))
            else:
                self.device_link_var.set("Conexion: -")

    def probe_device(self):
        try:
            po = self._build_runtime_options()
        except Exception as exc:
            messagebox.showerror("Configuracion invalida", str(exc))
            return

        self.device_status_var.set("Estado equipo: sondeando...")
        self._reset_probe_labels()
        self.update_idletasks()

        ser = None
        try:
            ser = open_serial_port(po)
            ack_type = ACK_TYPE.ACK_AFTER_EXEC if po.bulk else ACK_TYPE.NO_ACK_NEEDED
            pktrpl, _pktreq = send_request_and_receive_reply(
                po,
                ser,
                COMM_DEV_TYPE.FLYCONTROLLER,
                0,
                ack_type,
                CMD_SET_TYPE.GENERAL,
                0x01,
                bytes(),
                seqnum_check=not po.dry_test,
            )
            if pktrpl is None:
                raise ConnectionError("No hubo respuesta del Flight Controller.")

            pkthead = DJICmdV1Header.from_buffer_copy(pktrpl)
            payload = parse_version_inquiry_payload(pkthead, pktrpl)
            if payload is None or not hasattr(payload, "hw_version"):
                raise ValueError("La respuesta no contiene informacion de version reconocible.")

            hw_name = bytes(payload.hw_version).split(b"\0", 1)[0].decode("utf-8", errors="ignore").strip() or "desconocido"
            link_text = "USB bulk" if po.bulk else "Puerto {}".format(po.port)

            self.device_status_var.set("Estado equipo: respuesta de version recibida" if not po.dry_test else "Estado equipo: simulacion (dry test)")
            self.device_name_var.set("Perfil seleccionado: {} / HW informado: {}".format(self.selected_product_code(), hw_name))
            self.device_link_var.set("Conexion: {}".format(link_text if not po.dry_test else link_text + " (dry test)"))
            self.device_hw_var.set("HW: {}".format(hw_name))
            self.device_loader_var.set("Loader: {}".format(self._format_fw_version(payload.ldr_version)))
            self.device_app_var.set("App/FW: {}".format(self._format_fw_version(payload.app_version)))
            self.status_var.set("Version leida; el perfil seleccionado no confirma el modelo fisico.")
        except Exception as exc:
            self.device_status_var.set("Estado equipo: sin respuesta")
            self.device_link_var.set("Conexion: {}".format("USB bulk" if po.bulk else po.port or "-"))
            self.status_var.set("No se pudo leer informacion del equipo.")
            self.append_log("Probe error: {}".format(exc))
            if po.bulk and ("No backend available" in str(exc) or exc.__class__.__name__ == "NoBackendError"):
                friendly = (
                    "USB bulk no está disponible porque falta el backend libusb en Windows.\n\n"
                    "Opciones:\n"
                    "- Usa 'Puerto serie' si aparece un COM DJI.\n"
                    "- Instala/libera un driver libusb para el dispositivo si quieres usar bulk."
                )
                self.device_status_var.set("Estado equipo: bulk sin backend libusb")
                self.append_log(friendly)
                messagebox.showerror("Bulk no disponible", friendly)
            elif (not po.bulk) and po.port:
                details = self.port_details.get(po.port, {})
                if details and not details.get("is_dji"):
                    friendly = (
                        "El puerto seleccionado respondió mal o no corresponde claramente a un dispositivo DJI.\n\n"
                        "Prueba con otro puerto o pulsa 'Actualizar' con el dron conectado y encendido."
                    )
                    self.append_log(friendly)
                    messagebox.showerror("Sondeo fallido", friendly)
                else:
                    messagebox.showerror("Sondeo fallido", str(exc))
            else:
                messagebox.showerror("Sondeo fallido", str(exc))
        finally:
            if ser is not None:
                try:
                    ser.close()
                except Exception:
                    pass

    def update_command_preview(self):
        try:
            cmd = self.build_command()
            rendered = " ".join('"{}"'.format(part) if " " in part else part for part in cmd)
            self.command_preview_var.set(rendered)
        except Exception as exc:
            self.command_preview_var.set(str(exc))

    def append_log(self, text):
        self.log.insert("end", text)
        if not text.endswith("\n"):
            self.log.insert("end", "\n")
        self.log.see("end")
        self.update_idletasks()

    def clear_log(self):
        self.log.delete("1.0", "end")

    def open_yandron_panel(self):
        from yandron_panel import Panel
        Panel(self)

    def run_current_command(self):
        if self.current_service_name() == "YanDron":
            self.open_yandron_panel()
            return
        try:
            cmd = self.build_command()
            po = self._build_backend_options()
        except Exception as exc:
            messagebox.showerror("Configuracion invalida", str(exc))
            return

        self.append_log(">>> " + " ".join('"{}"'.format(part) if " " in part else part for part in cmd))
        if (po.product.name in MODERN_ALT_PRODUCT_CODES and po.svcmd == SERVICE_CMD.FlycParam and
          po.subcmd == FLYC_PARAM_CMD.SET):
            if not messagebox.askyesno(
                "Confirmar escritura moderna",
                "Vas a escribir un parametro en {}.\n\n"
                "Continua solo si ya hiciste respaldo y verificaste nombre, valor y rango."
                .format(po.product.name)
            ):
                self.status_var.set("Escritura moderna cancelada.")
                self.append_log("Escritura moderna cancelada por el usuario.")
                return
        self.status_var.set("Ejecutando comando...")
        self.update_idletasks()
        output = io.StringIO()
        try:
            with redirect_stdout(output), redirect_stderr(output):
                if po.svcmd == SERVICE_CMD.FlycParam:
                    do_flyc_param_request(po)
                elif po.svcmd == SERVICE_CMD.GimbalCalib:
                    do_gimbal_calib_request(po)
                elif po.svcmd == SERVICE_CMD.CameraCalib:
                    do_camera_calib_request(po)
                elif po.svcmd == SERVICE_CMD.ModuleInfo:
                    do_module_info_request(po)
                elif po.svcmd == SERVICE_CMD.RepairAssist:
                    do_repair_assist_request(po)
                else:
                    raise ValueError("Servicio no implementado.")
        except Exception as exc:
            log_text = output.getvalue()
            if log_text:
                self.append_log(log_text)
            self.append_log("Error: {}".format(exc))
            self.status_var.set("El comando termino con error.")
            messagebox.showerror("Error", str(exc))
            return

        log_text = output.getvalue()
        if log_text:
            self.append_log(log_text)
        self.status_var.set("Simulacion completada; no valida el equipo." if po.dry_test else "Operacion completada; revise las respuestas de cada modulo en el log.")


def main():
    app = OGServiceToolGui()
    app.mainloop()


if __name__ == "__main__":
    main()
