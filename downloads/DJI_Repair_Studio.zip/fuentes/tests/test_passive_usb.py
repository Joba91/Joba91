"""USB dependency fakes: no real drone or official DLL required."""
import tempfile
import unittest
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch,Mock
from types import SimpleNamespace
import usb.core
from vision_usb_passive import PassiveVisionUsbTransport,capture_passive,UsbOpeningError
from vision_protocol import decode_bytes
from studio_service import packet
from test_sensor_records import sample

class Endpoint:
    def __init__(self,address):
        self.bEndpointAddress=address;self.bmAttributes=2;self.wMaxPacketSize=512
        self.read=Mock(return_value=b'abc')
        self.write=Mock(side_effect=AssertionError('OUT forbidden'))

class Interface(list):
    bInterfaceNumber=4;bAlternateSetting=0;bInterfaceClass=255;bInterfaceSubClass=0x43;bInterfaceProtocol=1;bNumEndpoints=2
    def __init__(self):super().__init__([Endpoint(4),Endpoint(0x85)])

class Configuration(list):
    bConfigurationValue=1
    def __init__(self):super().__init__([Interface()])

class Device:
    iProduct=2;speed=3
    def __init__(self):
        self.cfg=Configuration();self.get_active_configuration=Mock(return_value=self.cfg)
        for name in ('set_configuration','set_interface_altsetting','reset','detach_kernel_driver','ctrl_transfer','clear_halt','write'):
            setattr(self,name,Mock(side_effect=AssertionError('Forbidden: '+name)))

class PassiveTransportTests(unittest.TestCase):
    def setUp(self):
        self.device=Device();self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.stack.enter_context(patch('vision_usb_passive.sys',SimpleNamespace(platform='linux')))
        self.backend=self.stack.enter_context(patch('usb.backend.libusb1.get_backend',return_value=object()))
        self.legacy_backend=self.stack.enter_context(patch('usb.backend.libusb0.get_backend',return_value=object()))
        self.selector=self.stack.enter_context(patch('vision_usb_passive.select_mi04',side_effect=lambda items:(items[0],{'selected_mi':4})))
        self.find=self.stack.enter_context(patch('usb.core.find',return_value=[self.device]))
        self.product=self.stack.enter_context(patch('usb.util.get_string',return_value='Mini 4 Pro-SYNTHETIC'))
        self.parent=self.stack.enter_context(patch('vision_usb_passive.parent_product_for_device',return_value={
            'product':'Mini 4 Pro-SYNTHETIC','source':'Windows physical USB parent / BusReportedDeviceDesc','metadata_only':True}))
        self.claim=self.stack.enter_context(patch('usb.util.claim_interface'))
        self.release=self.stack.enter_context(patch('usb.util.release_interface'))
        self.dispose=self.stack.enter_context(patch('usb.util.dispose_resources'))
    def assert_no_device_changes(self):
        for name in ('set_configuration','set_interface_altsetting','reset','detach_kernel_driver','ctrl_transfer','clear_halt','write'):
            getattr(self.device,name).assert_not_called()
        self.device.cfg[0][0].write.assert_not_called()
        self.device.cfg[0][1].write.assert_not_called()
    def test_only_matching_interface_read_and_release(self):
        t=PassiveVisionUsbTransport();self.assertFalse(hasattr(t,'write'))
        self.assertEqual(t.read(),b'abc')
        self.device.cfg[0][1].read.assert_called_once_with(512,timeout=200)
        self.claim.assert_called_once_with(self.device,4)
        t.close();t.close();self.release.assert_called_once_with(self.device,4)
        self.dispose.assert_called_once_with(self.device)
        self.assert_no_device_changes()
    def test_timeout_is_no_data_and_never_clears_halt(self):
        self.device.cfg[0][1].read.side_effect=usb.core.USBTimeoutError('timeout')
        t=PassiveVisionUsbTransport();self.assertEqual(t.read(),b'')
        self.assertEqual((t.attempts,t.timeouts),(1,1));t.close();self.assert_no_device_changes()
    def test_disconnect_is_not_swallowed_as_timeout(self):
        self.device.cfg[0][1].read.side_effect=usb.core.USBError('disconnected')
        t=PassiveVisionUsbTransport()
        with self.assertRaises(usb.core.USBError):t.read()
        t.close();self.assert_no_device_changes()
    def test_other_models_and_speeds_are_rejected(self):
        for product,speed in [('Mavic 4 Pro',3),('Mini 4 Pro-SYNTHETIC',2)]:
            self.product.return_value=product;self.device.speed=speed
            with self.assertRaises(RuntimeError):PassiveVisionUsbTransport()
        self.claim.assert_not_called();self.assert_no_device_changes()
    def test_wrong_endpoint_or_class_is_not_replaced_by_another_interface(self):
        self.device.cfg[0][1].bEndpointAddress=0x86
        with self.assertRaises(RuntimeError):PassiveVisionUsbTransport()
        self.device.cfg[0][1].bEndpointAddress=0x85;self.device.cfg[0].bInterfaceClass=8
        with self.assertRaises(RuntimeError):PassiveVisionUsbTransport()
        self.claim.assert_not_called();self.assert_no_device_changes()
    def test_missing_backend_and_ambiguous_devices_do_not_open(self):
        self.backend.return_value=None
        with self.assertRaises(RuntimeError):PassiveVisionUsbTransport()
        self.find.assert_not_called();self.backend.return_value=object()
        for devices in ([],[self.device,self.device]):
            self.find.return_value=devices
            with self.assertRaises(RuntimeError):PassiveVisionUsbTransport()
        self.device.get_active_configuration.assert_not_called()
    def test_driver_access_failure_disposes_without_install_or_detach(self):
        self.claim.side_effect=usb.core.USBError('access denied')
        with self.assertRaises(UsbOpeningError) as error:PassiveVisionUsbTransport()
        self.assertEqual(error.exception.diagnostics[0]['stage'],'claim_interface_4')
        self.assertEqual(error.exception.diagnostics[0]['exception_type'],'USBError')
        self.release.assert_not_called();self.dispose.assert_called_once_with(self.device)
        self.assert_no_device_changes()
    def test_libusb0_unknown_speed_is_reported_without_fake_high_speed(self):
        self.device.speed=None
        t=PassiveVisionUsbTransport('libusb0')
        self.assertEqual(t.evidence['backend'],'libusb0')
        self.assertFalse(t.evidence['speed_verified'])
        self.assertEqual(t.evidence['speed'],'no_informada_por_libusb0')
        self.backend.assert_not_called();self.assertEqual(t.read(),b'abc');t.close()
        self.assert_no_device_changes()
    def test_libusb1_unknown_speed_still_rejected(self):
        self.device.speed=None
        with self.assertRaises(UsbOpeningError) as error:PassiveVisionUsbTransport('libusb1')
        self.assertEqual(error.exception.diagnostics[0]['stage'],'check_configuration_and_speed')
        self.claim.assert_not_called()
    def test_windows_auto_prefers_legacy_without_replacing_driver(self):
        with patch('vision_usb_passive.sys',SimpleNamespace(platform='win32')):
            t=PassiveVisionUsbTransport()
        self.assertEqual(t.evidence['backend'],'libusb0');self.backend.assert_not_called()
        t.close();self.assert_no_device_changes()
    def test_windows_auto_falls_back_only_when_legacy_has_no_matching_device(self):
        self.find.side_effect=[[],[self.device]]
        with patch('vision_usb_passive.sys',SimpleNamespace(platform='win32')):
            t=PassiveVisionUsbTransport()
        self.assertEqual(t.evidence['backend'],'libusb1')
        self.assertEqual(t.evidence['backend_attempts'][0]['stage'],'enumerate_devices')
        self.assertEqual(t.evidence['backend_attempts'][0]['candidate_devices'],0)
        t.close();self.assert_no_device_changes()
    def test_unsupported_error_records_exact_pre_read_stage(self):
        self.legacy_backend.return_value=None
        self.device.get_active_configuration.side_effect=NotImplementedError('Operation not supported or unimplemented on this platform')
        with patch('vision_usb_passive.sys',SimpleNamespace(platform='win32')),self.assertRaises(UsbOpeningError) as error:
            PassiveVisionUsbTransport()
        self.assertEqual([d['stage'] for d in error.exception.diagnostics],['load_backend','get_active_configuration'])
        self.assertEqual(error.exception.diagnostics[1]['exception_type'],'NotImplementedError')
        self.claim.assert_not_called();self.assert_no_device_changes()
    def test_wrong_product_never_falls_back_to_another_api(self):
        self.product.return_value='Mavic 4 Pro'
        with patch('vision_usb_passive.sys',SimpleNamespace(platform='win32')),self.assertRaises(UsbOpeningError) as error:
            PassiveVisionUsbTransport()
        self.assertEqual(error.exception.diagnostics[0]['stage'],'check_product')
        self.backend.assert_not_called();self.claim.assert_not_called()
        self.assert_no_device_changes()
    def test_access_denied_never_falls_back_or_detaches_driver(self):
        self.claim.side_effect=usb.core.USBError('access denied')
        with patch('vision_usb_passive.sys',SimpleNamespace(platform='win32')),self.assertRaises(UsbOpeningError):
            PassiveVisionUsbTransport()
        self.backend.assert_not_called();self.assert_no_device_changes()
    def test_six_aliases_open_only_the_metadata_identified_mi04(self):
        from vision_usb_legacy import select_mi04,ALIAS_PREFIX
        devices=[]
        for index,mi in enumerate((2,3,5,6,7,4),1):
            device=Device();device._ctx=SimpleNamespace(dev=SimpleNamespace(filename=(ALIAS_PREFIX+f'{index:04d}--0x2ca3-0x0020').encode()))
            devices.append(device)
        self.find.return_value=devices
        mapping={index:mi for index,mi in enumerate((2,3,5,6,7,4),1)}
        def choose(items):return select_mi04(items,probe=lambda alias:[f'USB\\VID_2CA3&PID_0020&MI_{mapping[int(alias[-4:])]:02X}'])
        self.selector.side_effect=choose
        with patch('vision_usb_passive.sys',SimpleNamespace(platform='win32')):
            transport=PassiveVisionUsbTransport()
        self.assertIs(transport.device,devices[-1])
        self.assertEqual(transport.evidence['legacy_interface_selection']['enumerated_aliases'],6)
        for other in devices[:-1]:other.get_active_configuration.assert_not_called()
        self.claim.assert_called_once_with(devices[-1],4)
        self.backend.assert_not_called();transport.close()
    def test_generic_or_missing_interface_name_requires_verified_parent(self):
        for product in ('DJI USB Interface',None,''):
            self.product.return_value=product
            t=PassiveVisionUsbTransport('libusb0')
            self.assertEqual(t.evidence['product_identification_source'],self.parent.return_value['source'])
            self.assertEqual(t.evidence['observed']['interface_product_string'],product)
            t.close()
        self.assert_no_device_changes()
    def test_parent_metadata_is_closed_before_exclusive_pyusb_open(self):
        order=[]
        self.parent.side_effect=lambda dev:(order.append('parent') or self.parent.return_value)
        self.device.get_active_configuration.side_effect=lambda:(order.append('open') or self.device.cfg)
        self.product.return_value=None
        t=PassiveVisionUsbTransport('libusb0');t.close()
        self.assertEqual(order,['parent','open']);self.parent.assert_called_once_with(self.device)
    def test_wrong_parent_product_blocks_generic_child(self):
        self.product.return_value='DJI USB Interface';self.parent.return_value['product']='Mini 3 Pro-SYNTHETIC'
        with self.assertRaises(UsbOpeningError) as error:PassiveVisionUsbTransport('libusb0')
        d=error.exception.diagnostics[0]
        self.assertEqual(d['stage'],'check_parent_product')
        self.assertEqual(d['observed']['interface_product_string'],'DJI USB Interface')
        self.assertEqual(d['observed']['physical_parent_product']['product'],'Mini 3 Pro-SYNTHETIC')
        self.claim.assert_not_called();self.assert_no_device_changes()
    def test_explicit_other_model_is_never_overridden_by_parent(self):
        for name in ('Mavic 3','Mini 3 Pro','DJI Air 3','Avata 2'):
            self.product.return_value=name
            with self.assertRaises(UsbOpeningError) as error:PassiveVisionUsbTransport('libusb0')
            self.assertEqual(error.exception.diagnostics[0]['stage'],'check_product')
        self.claim.assert_not_called();self.assert_no_device_changes()
    def test_parent_failure_retains_both_observations_and_never_claims(self):
        self.product.return_value=None;self.parent.side_effect=RuntimeError('parent not available')
        with self.assertRaises(UsbOpeningError) as error:PassiveVisionUsbTransport('libusb0')
        d=error.exception.diagnostics[0]
        self.assertEqual(d['stage'],'read_parent_product_metadata')
        self.assertIn('parent not available',d['observed']['parent_metadata_error']['message'])
        self.assertIsNone(d['observed']['interface_product_string']);self.claim.assert_not_called()
    def test_descriptor_unavailable_can_use_positive_parent(self):
        self.product.side_effect=ValueError('language ID unavailable')
        t=PassiveVisionUsbTransport('libusb0')
        self.assertIn('product_read_error',t.evidence['observed']);t.close();self.assert_no_device_changes()
    def test_descriptor_access_denied_or_busy_is_not_bypassed(self):
        for code in (1,13,16):
            self.product.side_effect=usb.core.USBError('denied or busy',errno=code)
            with self.assertRaises(UsbOpeningError) as error:PassiveVisionUsbTransport('libusb0')
            self.assertEqual(error.exception.diagnostics[0]['stage'],'read_product_descriptor')
        self.claim.assert_not_called()
    def test_modern_backend_never_uses_legacy_parent_fallback(self):
        self.product.return_value=None
        with self.assertRaises(UsbOpeningError):PassiveVisionUsbTransport('libusb1')
        self.parent.assert_not_called();self.claim.assert_not_called()

class Clock:
    def __init__(self):self.now=0
    def __call__(self):return self.now

class Receiver:
    def __init__(self,clock,chunks):
        self.clock=clock;self.chunks=iter(chunks);self.attempts=0;self.timeouts=0;self.closed=False
        self.evidence={'interface':4,'bulk_in':'85'}
    def read(self):
        self.clock.now+=1;self.attempts+=1
        item=next(self.chunks,b'')
        if isinstance(item,Exception):raise item
        if not item:self.timeouts+=1
        return item
    def close(self):self.closed=True

class PassiveCaptureTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.path=Path(self.tmp.name)/'capture.bin';self.clock=Clock();self.progress=[]
    def run_capture(self,chunks,**kwargs):
        self.receiver=Receiver(self.clock,chunks)
        return capture_passive(self.path,'01.00.1100',transport_factory=lambda:self.receiver,
            clock=self.clock,progress=self.progress.append,**kwargs)
    def test_receives_raw_bytes_and_percentage_measures_time_only(self):
        r=self.run_capture([b'ab',b'cd'])
        self.assertEqual(self.path.read_bytes(),b'abcd');self.assertEqual(r['received_bytes'],4)
        self.assertEqual(r['state'],'confirmado');self.assertTrue(self.receiver.closed)
        self.assertEqual(self.progress[-1]['percent'],100)
        self.assertTrue(all(e['basis']=='tiempo_de_recepcion' for e in self.progress))
        self.assertEqual(r['device_health'],'desconocido');self.assertFalse(r['firmware_read_from_device'])
        self.assertEqual((r['bulk_out_bytes'],r['protocol_commands_sent'],r['device_writes']),(0,0,0))
    def test_empty_capture_is_not_sensor_failure_or_health(self):
        r=self.run_capture([])
        self.assertEqual(r['state'],'desconocido');self.assertEqual(r['received_bytes'],0)
        self.assertTrue(r['reception_completed']);self.assertFalse(r['live_sensor_query_validated'])
    def test_interruption_keeps_partial_file_and_never_100(self):
        r=self.run_capture([b'partial'],cancelled=lambda:self.clock.now>=1)
        self.assertEqual(self.path.read_bytes(),b'partial');self.assertEqual(r['stop_reason'],'detenida_por_usuario')
        self.assertFalse(r['reception_completed']);self.assertLess(self.progress[-1]['percent'],100)
        self.assertTrue(self.receiver.closed)
    def test_read_error_retains_bytes_and_error(self):
        r=self.run_capture([b'partial',OSError('USB unplugged')])
        self.assertEqual(r['state'],'error');self.assertIn('USB unplugged',r['error'])
        self.assertEqual(self.path.read_bytes(),b'partial');self.assertTrue(self.receiver.closed)
        self.assertLess(self.progress[-1]['percent'],100)
    def test_byte_limit_is_not_full_duration(self):
        with patch('vision_usb_passive.MAX_BYTES',3):r=self.run_capture([b'abcd'])
        self.assertEqual(self.path.read_bytes(),b'abc');self.assertEqual(r['stop_reason'],'limite_de_bytes')
        self.assertFalse(r['reception_completed']);self.assertLess(self.progress[-1]['percent'],100)
    def test_no_overwrite_and_validation_before_usb(self):
        self.path.write_bytes(b'original');factory=Mock()
        with self.assertRaises(FileExistsError):capture_passive(self.path,'01.00.1100',transport_factory=factory)
        with self.assertRaises(ValueError):capture_passive(self.path,'01.00.0200',transport_factory=factory)
        factory.assert_not_called();self.assertEqual(self.path.read_bytes(),b'original')
    def test_cancel_before_open_creates_no_file_or_device(self):
        factory=Mock()
        with self.assertRaises(InterruptedError):capture_passive(self.path,'01.00.1100',cancelled=lambda:True,transport_factory=factory)
        factory.assert_not_called();self.assertFalse(self.path.exists())
    def test_open_failure_is_recorded_without_guessing_identity(self):
        factory=Mock(side_effect=OSError('Driver access unavailable'))
        r=capture_passive(self.path,'01.00.1100',transport_factory=factory)
        self.assertEqual(r['state'],'error');self.assertEqual(r['usb'],{})
        self.assertEqual(r['bulk_in_attempts'],0);self.assertFalse(r['reception_completed'])
    def test_initialization_diagnostics_survive_factory_failure(self):
        diagnostics=[{'backend':'libusb1','stage':'get_active_configuration','exception_type':'NotImplementedError','message':'unsupported'}]
        r=capture_passive(self.path,'01.00.1100',transport_factory=Mock(side_effect=UsbOpeningError(diagnostics)))
        self.assertEqual(r['opening_diagnostics'],diagnostics)
        self.assertEqual(r['bulk_in_attempts'],0);self.assertEqual(r['protocol_commands_sent'],0)
    def test_reception_close_failure_cannot_be_success(self):
        self.receiver=Receiver(self.clock,[]);self.receiver.close=Mock(side_effect=OSError('release failed'))
        r=capture_passive(self.path,'01.00.1100',transport_factory=lambda:self.receiver,clock=self.clock,progress=self.progress.append)
        self.assertEqual(r['state'],'error');self.assertFalse(r['reception_completed'])
        self.assertLess(self.progress[-1]['percent'],100)
    def test_disk_failure_cannot_finish_at_100_and_releases_usb(self):
        self.receiver=Receiver(self.clock,[b'bytes'])
        with patch('pathlib.Path.open') as output:
            output.return_value.__enter__.return_value.write.side_effect=OSError('disk full')
            r=capture_passive(self.path,'01.00.1100',transport_factory=lambda:self.receiver,clock=self.clock,progress=self.progress.append)
        self.assertEqual(r['state'],'error');self.assertFalse(r['reception_completed'])
        self.assertIn('disk full',r['error']);self.assertTrue(self.receiver.closed)
        self.assertLess(self.progress[-1]['percent'],100)
    def test_binary_sensor_conversion_requires_valid_crc_and_keeps_unknown_identity(self):
        frame=packet(0x12,0x2a,900,0x24,0x26,sample(),flags=0)
        result=decode_bytes(frame[:8]+frame[8:])
        self.assertEqual(result['perception_records']['counts'],{'records':1,'decoded':1})
        self.assertEqual(result['perception_records']['observations_preview'][0]['serial_from_payload'],'ABCTAC10071234')
        self.assertEqual(result['identity']['state'],'desconocido')
        damaged=bytearray(frame);damaged[-1]^=1
        self.assertEqual(decode_bytes(damaged)['perception_records']['counts'],{})

if __name__=='__main__':unittest.main()
