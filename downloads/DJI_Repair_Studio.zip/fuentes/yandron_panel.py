"""YanDron integration panel for DJI REPAIR. No hardware access on import."""
import json
import queue
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from types import SimpleNamespace
from yandron_core import Session, ACTIONS, MODELS, analyze, validate, Cancelled, packet, unpack_hex
from yandron_protocol import Decoder

class Panel(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title('DJI REPAIR Studio — YanDron')
        width=min(1280,max(1000,self.winfo_screenwidth()-60))
        height=min(860,max(650,self.winfo_screenheight()-80))
        self.geometry(f'{width}x{height}'); self.minsize(1000,650)
        self.transient(parent); self.grab_set()
        self.running = False
        self.events = queue.Queue(); self.stop = threading.Event()
        self.report = None
        selected = parent.selected_product_code()
        self.model = tk.StringVar(value='Mavic 3' if selected == 'WM260' else 'Selecciona el modelo real')
        self.firmware = tk.StringVar()
        self.action = tk.StringVar(value=ACTIONS[0])
        self.prepared = tk.BooleanVar(value=False)
        self.status = tk.StringVar(value='Integracion experimental. Cada operacion abre y cierra la conexion de DJI REPAIR.')
        self.rx_ascii = tk.BooleanVar(value=False)
        self.rx_filter = tk.StringVar()
        self.totals = tk.StringVar(value='Total sent: 0 bytes    Total received: 0 bytes')
        self.tx_count = self.rx_count = 0
        self.fields = {}
        self.configure(padx=8, pady=8)
        self.rowconfigure(0, weight=1); self.columnconfigure(1, weight=1)
        left = ttk.Frame(self, width=315)
        left.grid(row=0, column=0, sticky='ns', padx=(0,8)); left.grid_propagate(False)
        left.columnconfigure(0,weight=1); left.rowconfigure(1,weight=1)
        connection = ttk.LabelFrame(left, text='Connection', padding=8)
        connection.grid(row=0,column=0,sticky='ew')
        label = 'USB bulk / interfaz actual' if parent.connection_mode.get() == 'bulk' else 'Serial: ' + parent.port_var.get()
        ttk.Label(connection,text='LibUSB / Serial — '+label,wraplength=280).pack(anchor='w')
        ttk.Label(connection,text='Modelo declarado').pack(anchor='w',pady=(8,0))
        ttk.Combobox(connection,textvariable=self.model,values=MODELS,state='readonly').pack(fill='x')
        ttk.Label(connection,text='Firmware DJI Fly (NN.NN.NNNN)').pack(anchor='w',pady=(6,0))
        ttk.Entry(connection,textvariable=self.firmware).pack(fill='x')
        ttk.Checkbutton(connection,text='Entre en fabrica y ya reinicie',variable=self.prepared).pack(anchor='w',pady=6)
        ttk.Label(connection,text='Conexion propia; se libera al terminar cada accion.',wraplength=280).pack(anchor='w')
        programs = ttk.Notebook(left); programs.grid(row=1,column=0,sticky='nsew',pady=8)
        run=ttk.Frame(programs,padding=7);commands=ttk.Frame(programs,padding=7)
        programs.add(run,text='Run program');programs.add(commands,text='Send Commands')
        self.quick_buttons=[]
        for text,action in [('Gimbal JOINT COARSE calibration','JointCoarse'),('Do Gimbal LINEAR HALL Calibration','LinearHall'),('Read calibration progress (20 s)',ACTIONS[0])]:
            b=ttk.Button(run,text=text,command=lambda a=action:self.quick(a));b.pack(fill='x',pady=4);self.quick_buttons.append(b)
        ttk.Label(run,text='1. Start Factory Mode\n2. Reiniciar manualmente\n3. Calibrar\n4. Stop Factory Mode y reiniciar',wraplength=280).pack(anchor='w',pady=10)
        self.stop_button=ttk.Button(run,text='Stop reading (no frena motores)',command=self.stop.set,state='disabled');self.stop_button.pack(fill='x',pady=4)
        for text,action in [('Start Factory Mode','Entrar modo fabrica'),('Gimbal JointCoarse','JointCoarse'),('Gimbal Linear Hall','LinearHall'),('Stop Factory Mode','Salir modo fabrica')]:
            b=ttk.Button(commands,text=text,command=lambda a=action:self.quick(a));b.pack(fill='x',pady=4);self.quick_buttons.append(b)
        for text in ('Gimbal IMU Data — no importado','Reboot / Shutdown — manual','Get SN / Auto Cali — pendiente'):
            ttk.Button(commands,text=text,state='disabled').pack(fill='x',pady=4)
        ttk.Label(commands,text='El bloque IMU fijo del original no se escribe en tu equipo.',wraplength=280).pack(anchor='w',pady=8)
        foot=ttk.Frame(left);foot.grid(row=2,column=0,sticky='ew')
        ttk.Button(foot,text='About',command=self.about).pack(side='left')
        ttk.Button(foot,text='Help',command=self.help).pack(side='left',padx=6)
        ttk.Button(foot,text='Exit',command=self.close_window).pack(side='right')
        right=ttk.Frame(self);right.grid(row=0,column=1,sticky='nsew')
        right.columnconfigure(0,weight=1);right.rowconfigure(0,weight=1)
        tabs=ttk.Notebook(right);tabs.grid(row=0,column=0,sticky='nsew')
        transfer=ttk.Frame(tabs,padding=6);experimental=ttk.Frame(tabs,padding=8);generator=ttk.Frame(tabs,padding=8)
        tabs.add(transfer,text='Data transfer');tabs.add(experimental,text='Experimental');tabs.add(generator,text='Packet Generator')
        transfer.columnconfigure(0,weight=1);transfer.rowconfigure(0,weight=1)
        receive=ttk.LabelFrame(transfer,text='Receive',padding=6);receive.grid(row=0,column=0,sticky='nsew')
        receive.columnconfigure(0,weight=1);receive.rowconfigure(1,weight=1)
        filters=ttk.Frame(receive);filters.grid(row=0,column=0,sticky='ew',pady=(0,6))
        ttk.Label(filters,text='Format: HEX').pack(side='left')
        ttk.Checkbutton(filters,text='Duplicate as ASCII',variable=self.rx_ascii).pack(side='left',padx=8)
        ttk.Label(filters,text='Filter HEX:').pack(side='left')
        ttk.Entry(filters,textvariable=self.rx_filter,width=18).pack(side='left')
        ttk.Button(filters,text='Clear',command=lambda:self.rx_filter.set('')).pack(side='left',padx=4)
        self.log=tk.Text(receive,wrap='word',state='disabled',font=('Consolas',9))
        self.log.grid(row=1,column=0,sticky='nsew')
        scrollbar=ttk.Scrollbar(receive,orient='vertical',command=self.log.yview);scrollbar.grid(row=1,column=1,sticky='ns');self.log.configure(yscrollcommand=scrollbar.set)
        transmit=ttk.LabelFrame(transfer,text='Transmit / HEX analysis (offline)',padding=6);transmit.grid(row=1,column=0,sticky='ew',pady=(8,0))
        self.hex=tk.Text(transmit,height=3,wrap='word',font=('Consolas',9));self.hex.pack(fill='x')
        self.hex.insert('1.0','55 0e 04 66 04 0a 8e ad 80 04 08 01 fb 95')
        hexbar=ttk.Frame(transmit);hexbar.pack(fill='x',pady=5)
        ttk.Button(hexbar,text='Analyze DUML',command=self.analyze_packet).pack(side='left')
        ttk.Button(hexbar,text='Find all DUMLs',command=self.find_packets).pack(side='left',padx=4)
        ttk.Button(hexbar,text='Clear',command=lambda:self.hex.delete('1.0','end')).pack(side='left')
        ttk.Label(hexbar,text='La entrada libre no se envia al dron.').pack(side='right')
        convert=ttk.LabelFrame(experimental,text='HEX to ASCII',padding=8);convert.pack(fill='x')
        self.convert_hex=tk.Text(convert,height=4);self.convert_hex.pack(fill='x')
        ttk.Button(convert,text='Convert HEX to ASCII',command=self.convert).pack(anchor='e',pady=6)
        self.convert_ascii=tk.Text(convert,height=4);self.convert_ascii.pack(fill='x')
        ttk.Label(experimental,text='No se importaron escrituras de parametros, firmware ni coeficientes IMU fijos.',wraplength=700).pack(anchor='w',pady=12)
        params=ttk.LabelFrame(generator,text='Parameters',padding=8);params.pack(fill='x')
        for row,(name,default) in enumerate([('Sender (HEX)','0a'),('Receiver (HEX)','04'),('Sequence (decimal)','0'),('CMD Set (HEX)','00'),('CMD ID (HEX)','01'),('Flags (HEX)','40'),('Payload (HEX)','')]):
            variable=tk.StringVar(value=default);self.fields[name]=variable
            ttk.Label(params,text=name).grid(row=row,column=0,sticky='w',pady=3)
            ttk.Entry(params,textvariable=variable).grid(row=row,column=1,sticky='ew',pady=3,padx=8)
        params.columnconfigure(1,weight=1)
        ttk.Button(generator,text='Generate DUML',command=self.generate).pack(anchor='w',pady=8)
        self.generated=tk.Text(generator,height=5,wrap='word',font=('Consolas',10));self.generated.pack(fill='x')
        ttk.Label(generator,text='Generacion offline: calcula longitud, CRC8 y CRC16. Los comandos al equipo se limitan a las acciones del panel izquierdo.',wraplength=700).pack(anchor='w',pady=8)
        bar=ttk.Frame(right);bar.grid(row=1,column=0,sticky='ew',pady=8)
        self.run_button=ttk.Button(bar,text='Listen to gimbal (20 s)',command=lambda:self.quick(ACTIONS[0]));self.run_button.pack(side='left')
        self.save_button=ttk.Button(bar,text='Save report',command=self.save,state='disabled');self.save_button.pack(side='right')
        ttk.Label(bar,textvariable=self.totals).pack(side='right',padx=10)
        ttk.Label(self,textvariable=self.status,wraplength=1200).grid(row=1,column=0,columnspan=2,sticky='ew',pady=(8,0))
        self.protocol('WM_DELETE_WINDOW',self.close_window)
        self.parent_close_handler=parent.protocol('WM_DELETE_WINDOW')
        parent.protocol('WM_DELETE_WINDOW',self.close_window)
        self.poll_id=self.after(100,self.poll)

    def quick(self,action):
        self.action.set(action);self.run()

    def about(self):
        messagebox.showinfo('DJI REPAIR + YanDron','Interfaz reconstruida a partir de los controles y textos del programa proporcionado.\nIntegracion Python experimental; no ejecuta sus DLL.\nNo se ha validado con hardware.',parent=self)

    def help(self):
        messagebox.showinfo('Help','Start Factory Mode → reiniciar manualmente → marcar casilla → elegir calibracion → Stop Factory Mode → reiniciar.\n\nEl gimbal se mueve; libera su recorrido y retira helices y protector. YanDron advierte posibles errores 40011/40021.\nNo se escribe el bloque IMU fijo; no se promete eliminar 40021.\nClassic y Mavic 4 Pro no estan habilitados. Stop reading NO frena el gimbal.',parent=self)

    def generate(self):
        try:
            values={k:v.get().strip() for k,v in self.fields.items()}
            sequence=int(values['Sequence (decimal)'])
            fields=[int(values[k],16) for k in ('Sender (HEX)','Receiver (HEX)','CMD Set (HEX)','CMD ID (HEX)','Flags (HEX)')]
            if not 0<=sequence<=65535 or any(not 0<=x<=255 for x in fields):raise ValueError('Campos fuera de rango')
            payload=unpack_hex(values['Payload (HEX)']) if values['Payload (HEX)'] else b''
            result=packet(fields[0],fields[1],sequence,fields[2],fields[3],payload,fields[4])
            self.generated.delete('1.0','end');self.generated.insert('1.0',result.hex(' '))
        except ValueError as exc:messagebox.showerror('Generator',str(exc),parent=self)

    def convert(self):
        try:
            result=unpack_hex(self.convert_hex.get('1.0','end')).decode('ascii',errors='replace')
            self.convert_ascii.delete('1.0','end');self.convert_ascii.insert('1.0',result)
        except ValueError as exc:messagebox.showerror('HEX',str(exc),parent=self)

    def find_packets(self):
        try:
            decoder=Decoder();frames=decoder.feed(unpack_hex(self.hex.get('1.0','end')))
            self.append(json.dumps({'paquetes_validos':[f.hex(' ') for f in frames],'invalidos':decoder.invalid,'bytes_pendientes':len(decoder.buffer)},indent=2))
        except ValueError as exc:messagebox.showerror('HEX',str(exc),parent=self)

    def append(self,text):
        if text.startswith(('TX ', 'RX ')):
            raw=bytes.fromhex(text[3:])
            if text.startswith('TX '):self.tx_count+=len(raw)
            else:self.rx_count+=len(raw)
            self.totals.set(f'Total sent: {self.tx_count} bytes    Total received: {self.rx_count} bytes')
            value=self.rx_filter.get().replace(' ','').lower()
            if text.startswith('RX ') and value and value not in raw.hex():return
            if self.rx_ascii.get():text+=' |ASCII: '+''.join(chr(c) if 32<=c<127 else '.' for c in raw)
        self.log.configure(state='normal');self.log.insert('end',text+'\n');self.log.see('end');self.log.configure(state='disabled')

    def analyze_packet(self):
        try:
            result=analyze(self.hex.get('1.0','end'))
            self.append(json.dumps(result,ensure_ascii=False,indent=2))
        except ValueError as exc:messagebox.showerror('HEX invalido',str(exc),parent=self)

    def run(self):
        if self.running:return
        action=self.action.get();model=self.model.get();firmware=self.firmware.get().strip()
        try:
            validate(model,firmware,action,self.prepared.get())
            po=self.parent._build_runtime_options()
            if po.dry_test:raise ValueError('Esta seccion no simula calibraciones. Desactiva Dry test para conectar o usa el analizador HEX sin conexion.')
            # Use the same backend and USB selection that already worked in DJI REPAIR.
            po=SimpleNamespace(**vars(po));po.timeout=200;po.verbose=0
        except Exception as exc:
            messagebox.showerror('Configuracion',str(exc),parent=self);return
        if action in ('JointCoarse','LinearHall'):
            if not messagebox.askyesno('Calibracion experimental',
                f'{action} en {model}, firmware {firmware}.\n\n'
                'El gimbal se movera. Retira helices y protector; deja libre su recorrido. '
                'El programa de origen advierte posibles errores 40011/40021. '
                'Esta integracion no se ha probado con hardware y no copia sus datos IMU fijos.\n\n'
                'Continuar?',parent=self):return
        elif action in ('Entrar modo fabrica','Salir modo fabrica'):
            if not messagebox.askyesno('Cambio de modo',f'{action} en {model}. Despues debes reiniciar manualmente. Continuar?',parent=self):return
        self.stop.clear();self.running=True
        self.run_button.configure(state='disabled');[b.configure(state='disabled') for b in self.quick_buttons];self.stop_button.configure(state='normal');self.save_button.configure(state='disabled')
        self.report={'origen':'YanDron proporcionado por el usuario; integracion experimental',
                     'modelo_declarado':model,'firmware_declarado':firmware,'accion':action,
                     'fecha_unix':time.time(),'resultado':None,'paquetes':[],'imu_escrita':False}
        self.status.set('Ejecutando '+action)
        threading.Thread(target=self.worker,args=(po,action),daemon=True).start()

    def worker(self,po,action):
        transport=None;session=None
        try:
            from comm_og_service_tool import open_serial_port
            transport=open_serial_port(po)
            if not po.bulk:
                transport.timeout=0.1
            session=Session(transport,emit=lambda text:self.events.put(('log',text)),cancelled=self.stop.is_set)
            if action=='Entrar modo fabrica':result=session.factory(True)
            elif action=='Salir modo fabrica':result=session.factory(False)
            elif action in ('JointCoarse','LinearHall'):result=session.calibrate(action)
            else:result=session.monitor(20)
            self.events.put(('result',result))
        except Cancelled as exc:self.events.put(('error',{'estado':'lectura_detenida','detalle':str(exc)}))
        except Exception as exc:self.events.put(('error',{'estado':'fallo_o_no_confirmado','detalle':str(exc)}))
        finally:
            if session:self.events.put(('packets',session.events))
            if transport:
                try:transport.close()
                except Exception as exc:self.events.put(('log','Error al cerrar: '+str(exc)))
            self.events.put(('done',None))

    def poll(self):
        try:
            while True:
                kind,value=self.events.get_nowait()
                if kind=='log':self.append(value)
                elif kind in ('result','error'):
                    self.report['resultado']=value
                    self.status.set(value['estado']+': '+value['detalle'])
                    self.append(json.dumps(value,ensure_ascii=False,indent=2))
                elif kind=='packets':self.report['paquetes']=value
                elif kind=='done':
                    self.running=False;self.run_button.configure(state='normal');[b.configure(state='normal') for b in self.quick_buttons];self.stop_button.configure(state='disabled');self.save_button.configure(state='normal')
                    if self.report['accion'] in ('Entrar modo fabrica','Salir modo fabrica'):self.prepared.set(False)
        except queue.Empty:pass
        self.poll_id=self.after(100,self.poll)

    def save(self):
        if self.running or not self.report:return
        path=filedialog.asksaveasfilename(parent=self,defaultextension='.json',initialfile='DJI-REPAIR-YanDron-informe.json',filetypes=[('JSON','*.json')])
        if path:
            try:
                with open(path,'w',encoding='utf-8') as f:json.dump(self.report,f,ensure_ascii=False,indent=2)
            except OSError as exc:messagebox.showerror('Informe',str(exc),parent=self)

    def close_window(self):
        if self.running:
            messagebox.showinfo('Operacion activa','Espera a que termine. Detener lectura no detiene fisicamente la calibracion.',parent=self);return
        self.after_cancel(self.poll_id)
        self.parent.protocol('WM_DELETE_WINDOW',self.parent_close_handler)
        self.grab_release();self.destroy()
