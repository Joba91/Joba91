"""One main window. --smoke-test validates startup without opening a drone."""
import json
import sys
import tkinter as tk
from pathlib import Path

def main():
    from studio_app import StudioApp
    app = StudioApp()
    if '--smoke-test' in sys.argv:
        app.update()
        app.offline('Generar')
        generated = app.packet_output.get('1.0', 'end').strip()
        app.offline('Analizar')
        analyzed = json.loads(app.packet_output.get('1.0', 'end'))
        report = {
            'interfaz': app.title(),
            'ventanas_principales': 1 + sum(isinstance(w, tk.Toplevel) for w in app.winfo_children()),
            'generador': generated,
            'analizador_payload': analyzed['payload'],
            'python': sys.version,
            'usb_backend_cargado': None,
            'operaciones_usb_ejecutadas': 0,
        }
        if sys.platform == 'win32':
            import usb.backend.libusb1
            native = Path(getattr(sys, '_MEIPASS', Path(__file__).parent)) / 'libusb-1.0.dll'
            report['usb_backend_cargado'] = usb.backend.libusb1.get_backend(find_library=lambda name: str(native)) is not None
        app.close_window()
        path = Path(sys.argv[sys.argv.index('--smoke-test')+1])
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        return
    app.mainloop()

if __name__ == '__main__':
    main()
