"""Standalone entry point. --smoke-test produces a local diagnostic without USB I/O."""
import json
import sys
from pathlib import Path

def main():
    from comm_og_service_tool_gui import OGServiceToolGui
    app = OGServiceToolGui()
    if '--smoke-test' in sys.argv:
        from yandron_panel import Panel
        app.update()
        panel = Panel(app); panel.update()
        panel.generate(); panel.analyze_packet()
        report = {'interfaz': app.title(), 'panel': panel.title(),
                  'generador': panel.generated.get('1.0','end').strip(),
                  'analizador': '"payload": "01"' in panel.log.get('1.0','end'),
                  'python': sys.version, 'usb_backend_cargado': False}
        import usb.backend.libusb1
        native = Path(getattr(sys, '_MEIPASS', Path(__file__).parent)) / 'libusb-1.0.dll'
        report['usb_backend_cargado'] = usb.backend.libusb1.get_backend(find_library=lambda name: str(native)) is not None
        # Deliberately does not enumerate/open a drone in this validation mode.
        panel.close_window(); app.destroy()
        path = Path(sys.argv[sys.argv.index('--smoke-test')+1])
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
        return
    def open_panel():
        app.notebook.select(5)
        app.open_yandron_panel()
    app.after(200, open_panel)
    app.mainloop()

if __name__ == '__main__': main()
